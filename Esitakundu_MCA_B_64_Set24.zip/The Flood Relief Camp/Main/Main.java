import java.sql.*;
import java.util.Scanner;

public class Main {

    static Scanner sc = new Scanner(System.in);

    // Main Function - Menu Driven
    public static void main(String[] args) {
        while (true) {
            System.out.println("----- Relief Camp System -----");
            System.out.println("1. Register Family");
            System.out.println("2. Record Distribution");
            System.out.println("3. Daily Summary");
            System.out.println("4. Exit");
            System.out.print("Enter choice: ");

            int ch = sc.nextInt();

            switch (ch) {
                case 1:
                    registerFamily();
                    break;
                case 2:
                    recordDistribution();
                    break;
                case 3:
                    dailySummary();
                    break;
                case 4:
                    System.exit(0);
                default:
                    System.out.println("Invalid choice!");
            }
        }
    }

    // Register family function
    static void registerFamily() {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Head of Family Name: ");
            sc.nextLine();
            String head = sc.nextLine();

            System.out.print("Village: ");
            String village = sc.nextLine();

            System.out.print("Number of Members: ");
            int members = sc.nextInt();

            String query = "INSERT INTO families (head, village, members) VALUES (?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS);

            ps.setString(1, head);
            ps.setString(2, village);
            ps.setInt(3, members);

            ps.executeUpdate();

            ResultSet keys = ps.getGeneratedKeys();
            if (keys.next()) {
                System.out.println("Family registered! ID = " + keys.getInt(1));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Record distribution function
    static void recordDistribution() {
        try (Connection con = DBConnection.getConnection()) {
            System.out.print("Family ID: ");
            int famId = sc.nextInt();

            System.out.print("Food(kg): ");
            double food = sc.nextDouble();

            System.out.print("Water(L): ");
            double water = sc.nextDouble();

            System.out.print("Medicine (true/false): ");
            boolean medicine = sc.nextBoolean();

            String query = "INSERT INTO distributions (fam_id, food_kg, water_l, medicine) VALUES (?, ?, ?, ?)";

            PreparedStatement ps = con.prepareStatement(query);
            ps.setInt(1, famId);
            ps.setDouble(2, food);
            ps.setDouble(3, water);
            ps.setBoolean(4, medicine);

            ps.executeUpdate();
            System.out.println("Distribution recorded.");

        } catch (SQLIntegrityConstraintViolationException e) {
            System.out.println("[ERROR] Already distributed to this family today.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Daily summary function
    static void dailySummary() {
        try (Connection con = DBConnection.getConnection()) {

            String fam = "SELECT COUNT(*) AS total FROM families";
            PreparedStatement p1 = con.prepareStatement(fam);
            ResultSet r1 = p1.executeQuery();
            int totalFamilies = 0;
            if (r1.next())
                totalFamilies = r1.getInt("total");

            String distQ = "SELECT COUNT(*) AS served, " +
                    "SUM(food_kg) AS totalFood, " +
                    "SUM(water_l) AS totalWater " +
                    "FROM distributions " +
                    "WHERE dist_date = CURDATE()";

            PreparedStatement p2 = con.prepareStatement(distQ);
            ResultSet r2 = p2.executeQuery();

            if (r2.next()) {
                System.out.println("----- Daily Summary -----");
                System.out.println("Total Families Registered : " + totalFamilies);
                System.out.println("Families Served Today    : " + r2.getInt("served"));
                System.out.println("Food Distributed         : " + r2.getDouble("totalFood") + " kg");
                System.out.println("Water Distributed        : " + r2.getDouble("totalWater") + " L");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
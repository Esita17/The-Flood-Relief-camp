CREATE DATABASE flood_relief;
USE flood_relief;

CREATE TABLE families (
    fam_id INT PRIMARY KEY AUTO_INCREMENT,
    head VARCHAR(50),
    village VARCHAR(30),
    members INT
);

CREATE TABLE distributions (
    dist_id INT PRIMARY KEY AUTO_INCREMENT,
    fam_id INT,
    dist_date DATE DEFAULT (CURRENT_DATE),
    food_kg DECIMAL(5,2),
    water_l DECIMAL(5,2),
    medicine BOOLEAN DEFAULT FALSE,
    UNIQUE KEY unique_entry (fam_id, dist_date),
    FOREIGN KEY (fam_id) REFERENCES families(fam_id)
);
